Write-Host "ok boot sd0:1" -ForegroundColor Cyan
# Call the python script instead of the -m flag
python server.py

