import http.server
import socketserver

PORT = 8080
DIRECTORY = "www"

class SolarisHandler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=DIRECTORY, **kwargs)
    
    # Custom Security Mod: Send a fake Server header
    def end_headers(self):
        self.send_header("Server", "Solaris-Pi/Hybrid-RISC")
        super().end_headers()

with socketserver.TCPServer(("", PORT), SolarisHandler) as httpd:
    print(f"[W] Solaris Web Server live at port {PORT}")
    httpd.serve_forever()
