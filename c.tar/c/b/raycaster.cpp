extern "C" {
    extern int calculate_loot_chance(int seed, int floor);
    extern int calculate_level(int xp);

    int world[100]; 
    struct Entity { float x, y, vx, vy; int type; float hp, mhp; int active; };
    Entity ents[2]; 
    
    float p_hp = 100.0f, p_mh = 100.0f, p_st = 100.0f;
    int p_xp = 0, p_scrap = 0;

    __attribute__((visibility("default")))
    void make_floor(int seed) {
        unsigned int next = seed;
        for(int i=0; i<100; i++) {
            next = next * 1103515245 + 12345;
            if (i < 10 || i > 89 || i % 10 == 0 || i % 10 == 9) world[i] = 1;
            else world[i] = (next % 6 == 0) ? 1 : 0;
        }
        world[11]=world[12]=world[21]=world[22]=0; // Spawn
        world[88]=0; // Exit

        ents[0] = {5.5f, 5.5f, 0, 0, 0, 50.0f, 50.0f, 1}; // Stalker
        ents[1] = {8.5f, 8.5f, 0, 0, 3, 1.0f, 1.0f, 1};    // EXIT
    }

    __attribute__((visibility("default")))
    void update_logic(float px, float py, int mov) {
        if (mov && p_st > 0) p_st -= 0.1f; else if (p_st < 100.0f) p_st += 0.4f;
        
        if(ents[0].active) {
            float dx = px - ents[0].x, dy = py - ents[0].y;
            float d = __builtin_sqrtf(dx*dx+dy*dy);
            if(d < 6.0f) { ents[0].vx += dx * 0.001f; ents[0].vy += dy * 0.001f; }
            ents[0].vx *= 0.9f; ents[0].vy *= 0.9f;
            float nx = ents[0].x + ents[0].vx, ny = ents[0].y + ents[0].vy;
            if (!world[(int)ny * 10 + (int)nx]) { ents[0].x = nx; ents[0].y = ny; }
            if (d < 0.4f) p_hp -= 0.1f; 
        }
        if (p_hp < 0) p_hp = 0;
    }

    __attribute__((visibility("default")))
    int fire_weapon(float px, float py, float pa) {
        if(!ents[0].active) return 0;
        float dx = ents[0].x - px, dy = ents[0].y - py;
        float ang = __builtin_atan2f(dy, dx) - pa;
        while(ang < -3.14f) ang += 6.28f; while(ang > 3.14f) ang -= 6.28f;
        if(__builtin_fabsf(ang) < 0.4f && __builtin_sqrtf(dx*dx+dy*dy) < 4.0f) {
            ents[0].hp -= 20; 
            if(ents[0].hp <= 0) { ents[0].active = 0; p_xp += 50; }
            return 1;
        }
        return 0;
    }

    __attribute__((visibility("default")))
    float cast_ray(float px, float py, float a) {
        float vx = __builtin_cosf(a), vy = __builtin_sinf(a), d = 0;
        while(d < 12.0f) {
            d += 0.05f;
            int tx = (int)(px + vx * d), ty = (int)(py + vy * d);
            if(tx >= 0 && tx < 10 && ty >= 0 && ty < 10 && world[ty * 10 + tx] == 1) return d;
        }
        return 12.0f;
    }

    __attribute__((visibility("default")))
    float get_p_stat(int id) {
        if(id==0) return p_hp; if(id==1) return p_st;
        if(id==3) return (float)calculate_level(p_xp);
        return p_mh;
    }

    __attribute__((visibility("default")))
    float get_ent_f(int i, int p) {
        if (p == 0) return ents[i].x; if (p == 1) return ents[i].y;
        if (p == 2) return (float)ents[i].type; return (float)ents[i].active;
    }
    
    __attribute__((visibility("default")))
    int get_map_val(int i) { return world[i]; }

    __attribute__((visibility("default")))
    void buy_upgrade(int type) {
        if(type == 0) { p_mh += 20; p_hp = p_mh; }
        if(type == 1) { p_st = 100; }
    }
}

