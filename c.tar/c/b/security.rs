#![no_std]
use core::panic::PanicInfo;

#[no_mangle]
pub extern "C" fn calculate_loot_chance(seed: i32, floor: i32) -> i32 {
    let chance = (seed % 100) + floor;
    if chance > 90 { 5 } else { 2 }
}

#[no_mangle]
pub extern "C" fn calculate_level(xp: i32) -> i32 {
    if xp < 100 { 1 } else if xp < 300 { 2 } else { 3 }
}

#[panic_handler]
fn panic(_info: &PanicInfo) -> ! { loop {} }

